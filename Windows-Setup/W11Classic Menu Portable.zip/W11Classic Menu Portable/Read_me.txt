Author: BlueLife , Velociraptor
www.sordum.org


############--Windows 11 Classic Context Menu v1.1 --############
(Thursday, 11 November 2021)

Changelog:

1. [ Added ] - All user support (Choose Menu - Apply to all users)
2. [ Added ] - Language support
3. [ Added ] - Move the Taskbar to the Top (Under menu)
4. [ Added ] - Some code improvements

---------------------------------------------------------------

############--Windows 11 Classic Context Menu v1.0--############
(Friday, 8 October 2021)

Windows 11 Classic Context Menu help users to toggle between Classic (Old) Context menu 
and default (new) Windows 11 Right click menu easily.





