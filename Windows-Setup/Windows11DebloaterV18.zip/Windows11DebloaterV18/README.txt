File: README.TXT for Windows 11 Debloater Tool (Version 1.8) from www.FreeTimeTech.com
Based on 2 PowerShell Scripts (1) Chris Titus Tech GitHub PowerShell Scripts (2020-22): https://github.com/ChrisTitusTech/win10script
and (2) farag2 Sophia Script for Windows GitHub PowerShell Scripts (2022): https://github.com/farag2/Sophia-Script-for-Windows

►Link: https://freetimetech.com/windows-11-debloater-tool-debloat-gui/
►YouTube: Coming Soon! But similar to: https://www.youtube.com/watch?v=3KTRS1RpBmg

Check our Windows 10 Debloater from www.FreeTimeTech.com website: 
►Link: http://freetimetech.com/windows-10-clean-up-debloat-tool-by-ftt/

Check our full GUI (C#+WPF) version called 'SophiApp' on GitHub:
►Link: https://github.com/Sophia-Community/SophiApp
This other version is made in collaboration with farag2 (Dmitry Nefedov) and Inestic (Dmitry Demin).

Check our other version of Windows 10/11 Debloater called 'Sophia Script for Windows' on BenchTweakGaming.com website: 
►Link: https://benchtweakgaming.com/2020/10/27/windows-10-debloat-tool/
This other version is made in collaboration with farag2 (Dmitry Nefedov) and Inestic (Dmitry Demin).

UPDATE V1.8
-----------
Advanced Debloater tab for basic fine-tuning, Removed O&O Shutup, fixed bugs in V1.7, Rearranged files and folders.

UPDATE V1.7 (Revoked)
-----------
Added list counter to summary and output for EZ Debloater, Added more 3rd Party radiobuttons, Added Install radiobuttons for 
Windows UWP Apps, Update functions, Cleaned up code.

UPDATE v1.6
-----------
Added UI translation for 17 languages, EZ Debloater is now has two modes: 'Normal' and 'Edit'. 'Normal' shows the summarised 
selected script and 'Edit' is the PowerShell script.

UPDATE v1.5
-----------
Added ToolTip languages: Dutch, Greek, Arabic and Turkish.

UPDATE v1.4
-----------
Added ToolTip languages: German, Italian, and Romanian. Folder called 'Localizations' created to store all tooltips.txt files.

UPDATE v1.3
-----------
Added ToolTip languages: Portuguese, Japanese and Korean, Fixed some bugs

UPDATE v1.2
-----------
Added ToolTip languages: Russian, Spanish, French, Chinese, Polish and Vietnamese.

UPDATE v1.1
-----------
Toggle mode added to hide 'Read/Edit' button beside each radiobutton, Update EZ Debloater - Essential Tweaks, More 3rd 
Party, Updates and Fixes

INTRODUCTION
------------
Please read this document to understand how to use this program.

There is a 'EZ Debloater' tab page as main front of the program. It allows you to run common
PowerShell scripts to debloat Windows 11. There are several restore/undo scripts you can choose from 
after if you choose. Some buttons in the 'EZ Debloater' tab page has ToolTips (message popups) for 
more information.

Each button has a summarised information of the PowerShell script you can see first before running. 
To modify the PowerShell script you change the 'Mode' to 'Edit'. Change back to 'Normal' to see the 
refreshed summarised version of the script.

There is a 'Advanced Debloater' tab page to basic fine tune debloating from 4 presets. There is also 
a 'Undo All' to reset everything back to defaults. You can “See Script” to see your selections.

The other tabs allows you to create a PowerShell script file that you can run to finely tweak/'Debloat' 
Windows 11.

The options are arranged in different tabs and there is a preset 'Debloat Preset' in the Options menu. 
You can choose a preset first and add your own choices. There is a 'Windows Default Preset' to revert
back to Windows Default setttings. You can also create your own radiobutton presets and share. There 
is also a 'Opposite' menu choice to select the alternate radiobutton choices. This is good to revert 
the changes in a script to run.

In 'Normal' Mode, the 'Read/Edit' radiobutton is missing to clean up the interface. Switch to 'Edit' 
Mode to gain back the 'Read/Edit' button beside each radiobutton to see the PowerShell script.

You can directly run the PowerShell script from the program after creating your script.
Click the 'Run Powershell' button after you fill in the radiobutton choices and click the 
'Output PowerShell' button. The "Run PowerShell" button creates a PowerShell script called
'runpsscript.ps1' in the same directory and runs it.

OR save the PowerShell script as whatever you wish in the same directory with the other files then 
run it using the following commands.

But first, launch PowerShell (Run as administrator) and navigate to where your script is.

1. Set-ExecutionPolicy Unrestricted 
2. ./YOUR_SCRIPT_NAME.ps1

YOUR_SCRIPT_NAME is the name of the PowerShell script you just saved.

FILES
-----
There needs to be 13 files for this program to run properly.

►Windows11Debloater.exe : The GUI program.

EZ Debloater
------------
►ezdebloater.txt : contains the PowerShell scripts for the 'EZ Debloater' tab page.

Advanced Debloater
------------------
►advanceddebloater.txt : contains the PowerShell scripts for the 'Advanced Debloater' tab page.
►desktoppreset.txt : contains the 'Desktop' preset for 'Advanced Debloater'.
►laptoppreset.txt : contains the 'Laptop' preset for 'Advanced Debloater'.
►minimalpreset.txt : contains the 'Minimal' preset for 'Advanced Debloater'.
►vmpreset.txt : contains the 'Virtual Machine' preset for 'Advanced Debloater'.

Fine tuning Debloater
---------------------
►data.txt : contains the options(function names) to select from (usually only 2 
		options that something is Enable or Disable). Notice the sections 
		and how a comma and double quotes separate them. The last option in 
		each section does not have a comma. Add or substract from the set.
►functions.txt : contains the complete functions named from data.txt. These are the 
		commands that get run. Add or substract from the set.
►debloatpreset.txt : contains debloat preset. Click this option from the menu in program.
►defaultpreset.txt : contains default preset. Click this option from the menu in program.

Localizations - Translations
-------------
►tooltips.txt :	Contains ToolTips for each radiobutton option. Many languages so far.
►ui.txt :	Contains UI text for each UI element/control. Many languages so far.

►README.txt : This text file for information and link resources.